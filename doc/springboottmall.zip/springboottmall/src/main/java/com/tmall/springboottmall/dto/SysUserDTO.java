package com.tmall.springboottmall.dto;

import lombok.Data;

@Data
public class SysUserDTO {

	private String userName;
	private  String telphone;
	private String password;
	private Integer age;
	private String gender;
	
	
}
